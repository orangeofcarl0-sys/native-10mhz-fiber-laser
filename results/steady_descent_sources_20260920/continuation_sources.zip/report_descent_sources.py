"""Self-contained Chinese descent-source report with separate scientific figures."""
import json,io,base64
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from config import ROOT
plt.rcParams.update({'font.sans-serif':['Microsoft YaHei'],'axes.unicode_minus':False,'font.size':12})
a=json.loads((ROOT/'source_audit.json').read_text());parts=[]
def section(title,text,draw=None):
    image=''
    if draw:
        fig,ax=plt.subplots(figsize=(11,5.3));draw(ax);fig.tight_layout();buf=io.BytesIO();fig.savefig(buf,format='png',dpi=150);fig.savefig(ROOT/f'figure_{len(parts)+1:02d}.png',dpi=150);plt.close(fig)
        image='<img src="data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()+'">'
    parts.append('<section><h2>'+title+'</h2><p>'+text+'</p>'+image+'</section>')
section('研究问题与单状态对照','在上一轮 B 末态 R≈1.20814×10⁻³，检验新增方向能否提高当前受限步的实际下降。S1：当前 C 方向；S2：增加 375–750 GHz 环带方向；S3：增加最近三个新鲜历史方向；S4：增加最有利的物理参数坐标。共用当前 C 预条件器、Arnoldi 基底、残差定义及三个半径。S4 允许物理参数变化，其结论不代表原固定参数方程改善。')
section('比较规则与历史数据恢复','历史方向通过确定性重放上一段 30 步恢复，逐步残差及末态须匹配，随后在当前状态重新计算所有响应。每个候选须通过 Cauchy 模型下界、三个尺度的预测下降交叉检查（差异小于 5%）与完整映射下降比 ρ>0.1。新增组只有实际 merit 下降达到同半径有效 S1 的 1.25 倍，才有资格继续 30 步。此处 merit=‖R‖²/2。')
def cosine(ax):
    names=list(a['directions']);ax.bar(np.arange(len(names)),[a['directions'][v]['cosine'] for v in names]);ax.set_xticks(np.arange(len(names)),['当前 C','频谱环带','历史 1','历史 2','历史 3']);ax.set(ylabel='−R·(Jd) / (‖R‖‖Jd‖)');ax.axhline(0,color='gray');ax.grid(axis='y',alpha=.2)
section('当前残差与各方向响应的夹角','这里测量的是一个具体方向 d 的响应 Jd 与残差的夹角，不是残差向整个 Range(JE) 的投影。对下降方向，在无半径截断的线性模型中，最大相对 merit 下降等于该余弦的平方。小余弦不能单独证明整个输入子空间已达驻点。历史方向的余弦若为负，表示沿该方向当前上坡，但子空间仍可利用反向或组合。',cosine)
def gradients(ax):
    ax.bar(['C：中心差分','环带：中心差分'],[a['core_central_gradient_norm'],a['annulus']['gradient_norm']]);ax.set(ylabel='完整输出受限梯度范数',yscale='log');ax.grid(axis='y',alpha=.2)
section('核心频带与新增环带的梯度','这里的 GHz 是光场包络相对载频的傅里叶偏移频率，不是测距射频读出频点。两个频带均在原完整网格上计算完整残差内积。新增环带不包含反转或规范变量；流式计算中心差分及前向差分对照，不建立更大的稠密矩阵。梯度范数揭示一阶敏感度，是否有用还必须看受限模型和实际下降。',gradients)
def parameters(ax):
    names=list(a['parameters']);ax.bar(names,[a['parameters'][v]['bounded_prediction'] for v in names]);ax.set(ylabel='单参数模型下降（|Δq|≤0.003125）');ax.ticklabel_format(axis='y',style='sci',scilimits=(0,0));ax.grid(axis='y',alpha=.2)
section('物理参数方向及尺度',f"所有列在 27.5 mW、GDD=0.2 ps²、OC=0.8、CNT Psat=40 W 处计算。归一化单位分别为 5 mW、0.02 ps²、0.05、4 W；GDD 保持总腔长 20.42 m，Psat 保持恢复时间。先按半径 0.003125 的一维模型下降选择 {a['selected_parameter']}，没有新增人为方程。导数同时用 Δq=1e−3 与 5e−4 核对。",parameters)
table='<table><tr><th>参数</th><th>无约束线性最优 Δq</th><th>导数尺度差异</th></tr>'
for name,values in a['parameters'].items():
    table+=f"<tr><td>{name}</td><td>{values['free_scaled_step']:.5g}</td><td>{100*values['column_crosscheck']:.4g}%</td></tr>"
table+='</table>'
section('参数导数的一致性与线性步长', 'Δq 为上述归一化参数单位；无约束线性最优值只是局部模型诊断，不是已验证的可执行物理调参量。S4 候选另外受信赖域约束并运行完整模型。'+table)
def actual(ax):
    for i,g in enumerate(['S1','S2','S3','S4']):
        rows=[v for v in a['trials'] if v['group']==g];ax.bar(np.arange(3)+(i-1.5)*.19,[v['actual_reduction'] for v in rows],width=.19,label=g)
    ax.set_xticks(np.arange(3),[str(v) for v in a['radii']]);ax.set(xlabel='信赖域半径',ylabel='完整映射的实际 merit 下降');ax.legend();ax.ticklabel_format(axis='y',style='sci',scilimits=(0,0));ax.grid(axis='y',alpha=.2)
section('四组候选的实际单步下降','所有候选都从同一个保存态计算，图中没有串接前一个试步。模型下降与实际下降分别保留；候选未通过检查时，不能因柱形较高就宣称可用。',actual)
def gains(ax):
    for g in ['S2','S3','S4']:
        rows=[v for v in a['trials'] if v['group']==g and v['actual_gain_over_S1'] is not None];ax.plot([v['radius'] for v in rows],[v['actual_gain_over_S1'] for v in rows],'o-',label=g)
        bad=[v for v in rows if not v['passed']]
        if bad:ax.scatter([v['radius'] for v in bad],[v['actual_gain_over_S1'] for v in bad],marker='x',s=100,color='red')
    ax.axhline(1.25,ls='--',color='gray',label='续算门槛 1.25');ax.set(xlabel='信赖域半径',ylabel='实际下降 / 同半径 S1');ax.legend();ax.grid(alpha=.2)
section('新增方向的改善比例与续算门槛','红叉表示该候选未通过模型或实际下降检查。S1 实际下降非正时不定义改善比值，也不据此触发续算。必须同时满足物理可行、候选检查合格和至少 25% 的实际改善；不根据模型预测单独启动长程计算。',gains)
def rho(ax):
    for g in ['S1','S2','S3','S4']:
        rows=[v for v in a['trials'] if v['group']==g];ax.plot(a['radii'],[v['rho'] for v in rows],'o-',label=g)
    ax.axhline(.1,color='gray',ls='--');ax.set(xlabel='信赖域半径',ylabel='实际下降 / 模型下降 ρ');ax.legend();ax.grid(alpha=.2)
section('受限模型与实际映射的吻合','实际下降比检验线性模型在该半径是否可信。接近 1 说明预测吻合，不等于下降幅度大，也不等于即将收敛。',rho)
qualified=a['qualified'];section('对照结果与解释边界','达到预设续算门槛的候选：'+('；'.join(f"{v['group']}，Δ={v['radius']}，实际改善 {v['gain']:.3f} 倍" for v in qualified) if qualified else '无。按约定不启动新的 30 步续算。')+'。这些结果只覆盖指定频带、三个历史方向和四个局部参数方向；未审计的更高频段和其他方向仍存在；不能证明全空间驻点或不存在周期一根。下一步方案须根据实际对照结果决定。')
links=''
for name in ['source_audit.json','history_recovery.json','protocol.json','continuation.json','endpoint_checks.json']:
    if (ROOT/name).exists():links+=f'<a download="{name}" href="data:application/json;base64,{base64.b64encode((ROOT/name).read_bytes()).decode()}">{name}</a> '
html='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>原生10MHz：下降方向来源对照</title><style>body{margin:auto;max-width:1200px;padding:24px;background:#eef3f8;color:#17344a;font:18px/1.7 system-ui}section{padding:30px;margin:24px 0;background:white;border-radius:12px}h1,h2{color:#065783}img{width:100%;height:auto}a{overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;font-size:16px}td,th{border-bottom:1px solid #ccd9e5;padding:8px;text-align:left}@media(max-width:600px){body{padding:10px}section{padding:15px}h1{font-size:25px}h2{font-size:21px}}</style><h1>原生10MHz：下降方向来源的单状态四组对照</h1>'+links+''.join(parts)+'</html>'
(ROOT/'原生10MHz_下降方向来源与四组对照.html').write_text(html,encoding='utf8')
